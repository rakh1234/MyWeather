//
//  LocationWeatherScreen.swift
//  MyWeather3
//
//  Created by Razan on 25/01/2021.
//
import UIKit
import CoreLocation
//import CoreData
//NSFetchedResultsControllerDelegate

class LocationWeatherScreen: UIViewController, CanReceive {
    
    let locationManager = CLLocationManager()
    let networkManager = NetworkManager()
    var weatherModel: WeatherStruct?
    var weatherManager = WeatherDataModel(modelName: "weather")
    let animationsManager = SimpleAnimator()
    //var weatherDataModel: WeatherDataModel!
    //var fetchResultController: NSFetchedResultsController<Weather>!
    
    @IBOutlet weak var wrongLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var conditionIcon: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        setupLocationManager()
    }
    
    @IBAction func nextScreenTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "goToWeatherByCity", sender: self)
    }
    
    //func setUpFetchedResultsViewController() {
      //  let fetchRequest: NSFetchRequest<Weather> = Weather.fetchRequest()
      //  let sortDescriptor = NSSortDescriptor(key: "city", ascending: false)
       // fetchRequest.sortDescriptors = [sortDescriptor]
//fetchResultController = NSFetchedResultsController(fetchRequest: fetchRequest,  managedObjectContext: WeatherDataModel.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        
       // fetchResultController.delegate = self
      //  do {
        //    try fetchResultController.performFetch()
       // } catch {
       //     print(error.localizedDescription)
       // }
   // }
    
    func receivedCityName(city: String) {
        print(city)
        networkManager.getWeatherDataByCity(city: city) { (result) in
            switch result {
            case .success(let weatherModel):
                self.weatherModel = weatherModel
                DispatchQueue.main.async {
                    self.updateWeatherInfo(info: weatherModel)
                }
                print(weatherModel)
            case .failure(let error):
                DispatchQueue.main.async {
                    self.animationsManager.fadeInAndOutAnimation(view: self.wrongLabel)
                    
                }
                let alert = UIAlertController(title: "Error", message: "Please make sure to write the correct city name or check your Network", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToWeatherByCity" {
            guard let destinationVc = segue.destination as? WeatherByCityController else { return }
            destinationVc.delegate = self
        }
    }
    
    func setupViews() {
        wrongLabel.layer.opacity = 0
        conditionIcon.image = UIImage(named: "Cloud-Refresh")
        tempLabel.text = "--℃"
        cityLabel.text = "Updating..."
    }
    
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func updateWeatherInfo(info: WeatherStruct) {
        tempLabel.text = Int(info.main.temp).description + "℃"
        cityLabel.text = info.name
        conditionIcon.image = UIImage(named: weatherManager.updateWeatherIcon(condition: info.weather[0].id))
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        get {
            return .lightContent
        }
    }
}

//func downloadImage(completion: @escaping(Bool, Error?) -> Void ) {
   // let weather = Weather(context: self.weatherManager.viewContext)
   // for weather in weather {
     //   self.urlComponents = ""
     //   self.urlComponents = weather
    //}
   // NetworkManager.getWeatherData(urlComponents: weather ?? "") { (data, error) in
            //if error == nil {
            //self.imageLoading(is: false)
               // weather.city = data
               // weather.city = self.urlComponents
               // weather.city = self.city
                //weather.temperature?.temperature = self.temperature
               // weather.condition?.condition = self.condition
           // }
           /// else {
              //  print(error?.localizedDescription ?? "problem in downloading image")
              //  }
       // do// {
          //   try self.dataController.viewContext.save()
           //  self.photoStore.removeAll()
           //  completion(true, nil)//
         //   } catch {
         //    print("Error saving into Core Data")
        //     completion(false, error)
         //   }
      //  }
   //  }

extension LocationWeatherScreen: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        if location.horizontalAccuracy > 0 {
            locationManager.stopUpdatingLocation()
            locationManager.delegate = nil
            print("long = \(location.coordinate.longitude)", "lat = \(location.coordinate.latitude)")
            let latitude = location.coordinate.latitude.description
            let longitude = location.coordinate.longitude.description
            
            networkManager.getWeatherData(lat: latitude, lon: longitude) { (result) in
                switch result {
                case .success(let weatherModel):
                    self.weatherModel = weatherModel
                    DispatchQueue.main.async {
                        self.updateWeatherInfo(info: weatherModel)
                    }
                    print(weatherModel)
                case .failure(let error):
                    let alert = UIAlertController(title: "Error", message: "Please make sure to write the correct city name or check your Network", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
}
