//
//  WeatherByCityController.swift
//  MyWeather3
//
//  Created by Razan on 25/01/2021.
//
import Foundation
import UIKit

class WeatherByCityController: UIViewController {
    
    var delegate: CanReceive?
    var activityView: UIActivityIndicatorView?
    
    @IBOutlet weak var updateWeatherButton: UIButton!
    @IBOutlet weak var cityTextField: UITextField!
    
    //activityIndicator
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    func setupViews() {
        updateWeatherButton.setCornerRadius(radius: 5)
        cityTextField.setCornerRadius(radius: 5)
        cityTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 8, height: 0))
        cityTextField.leftViewMode = .always
    }
    
    @IBAction func closeButtonTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func updateWeatherByCityTapped(_ sender: UIButton) {
        self.activityIndicator.alpha = 1
        self.activityIndicator.startAnimating()

        delegate?.receivedCityName(city: cityTextField.text ?? "")
        dismiss(animated: true, completion: nil)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        get {
            return .lightContent
        }
    }

    func setdownloadModeStart(_ downloadModeStart: Bool) {
        if downloadModeStart {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
        
        updateWeatherButton.isEnabled = !downloadModeStart
    }
    
    func removeActivitiindicator(){
        activityIndicator.removeFromSuperview()
        activityIndicator = nil
    }
}
