//
//  Protocols.swift
//  MyWeather3
//
//  Created by Razan on 25/01/2021.
//
import Foundation

protocol CanReceive {
    func receivedCityName(city: String)
}
