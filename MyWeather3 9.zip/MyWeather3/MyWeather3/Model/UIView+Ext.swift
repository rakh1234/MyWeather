//
//  UIView+Ext.swift
//  MyWeather3
//
//  Created by Razan on 25/01/2021.
//
import Foundation
import UIKit

extension UIView {
    func setCornerRadius(radius: CGFloat) {
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
}
