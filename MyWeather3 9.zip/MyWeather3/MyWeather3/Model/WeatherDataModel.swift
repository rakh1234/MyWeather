//
//  WeatherDataModel.swift
//  MyWeather3
//
//  Created by Razan on 25/01/2021.
//
import Foundation
import CoreData

class WeatherDataModel {
    
    var temperature : Int = 0
    var condition: Int = 0
    var city : String = ""
    let persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    init(modelName: String) {
        persistentContainer = NSPersistentContainer(name: modelName)
    }
    
    func updateWeatherIcon(condition: Int) -> String {
        
        switch condition {
        case 0...300 :
            return "tstorm1"
        
        case 301...500 :
            return "shower3"
            
        case 501...600 :
            return "shower3"
            
        case 601...700 :
            return "snow4"
            
        case 701...771 :
            return "fog"
            
        case 772...799 :
            return "tstorm3"
            
        case 800 :
            return "sunny"
            
        case 801...804 :
            return "cloudy2"
            
        case 900...903, 905...1000  :
            return "tstorm3"
            
        case 903 :
            return "snow4"
            
        case 904 :
            return "sunny"
            
        default :
            return "Cloud-Refresh"
        }
    }
    
    func load(completion: (() -> Void)? = nil) {
        persistentContainer.loadPersistentStores { (storeDescription, error) in
            guard error == nil else {
                print(error!.localizedDescription)
                return
            }
            self.autoSaveViewContext()
            completion?()
        }
    }
    func autoSaveViewContext(interval: TimeInterval = 5) {
        print("Save made")
        guard interval > 0 else {
            print("Cannot autosave")
            return
        }
        
        if viewContext.hasChanges {
            try? viewContext.save()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + interval) {
            self.autoSaveViewContext(interval: interval)
        }
    }
}

struct WeatherStruct: Codable {
    var name: String
    var main: TemparatureData
    var weather: [WeatherData]
}

struct TemparatureData: Codable {
    var temp: Float
}

struct WeatherData: Codable {
    var id: Int
}
